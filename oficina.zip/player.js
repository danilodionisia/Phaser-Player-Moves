var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create, update: update });

//Cria as variáveis globais do jogo
var player;
var platforms;

//Função que faz o pre carregamento dos sprites
function preload() {
    game.load.image('sky', 'assets/sky.png');
	game.load.image('ground', 'assets/platform.png');
	game.load.spritesheet('jogador', 'assets/dude.png', 32, 48);	
}

//função que cria os objetos do jogo
function create() {
	
	//habilita a física do jogo	
	game.physics.startSystem(Phaser.Physics.ARCADE);		
	//adiciona o sprite do background do jogo
    game.add.sprite(0, 0, 'sky');
	
	//cria um grupo para trabalhar com o chão do jogo
    platforms = game.add.group();
	//habilita o corpo do chao
    platforms.enableBody = true;
	
	//cria a variavel que recebe o grupo do chão
    var ground = platforms.create(0, game.world.height - 64, 'ground');
    //cria a escala do chão no jogo
	ground.scale.setTo(2, 2);
	//torna o corpo do chão imóvel
    ground.body.immovable = true;
	
	//adiciona o sprite do player e ajusta a altura inicial do player
	player = game.add.sprite(32, game.world.height - 500, 'jogador');
    //habilita a física do player	
	game.physics.arcade.enable(player);
    
	//ajusta como o player irá quicar quando cai
	player.body.bounce.y = 0.1;
	//ajusta a gravidade do player
    player.body.gravity.y = 600;
	//cria limites para o player não ultrapassar as laterais do jogo
    player.body.collideWorldBounds = true;
	
	//cria as animações do player para a direita e esquerda
    player.animations.add('left', [0, 1, 2, 3], 10, true);
    player.animations.add('right', [5, 6, 7, 8], 10, true);
	
	//captura o teclado para movimentação do player
	cursors = game.input.keyboard.createCursorKeys();	
}

function update() {
	
	//cria a variavei que detecta a colisao entre o player e o chao
	var hitPlatform = game.physics.arcade.collide(player, platforms);	
	//ajusta a velocidade inicial do player
    player.body.velocity.x = 0;
	
	
    if (cursors.left.isDown){		
		//verifica se a tecla para a esquerda foi pressionada
        player.body.velocity.x = -350;
        player.animations.play('left');
    }
    else if (cursors.right.isDown){		
		//verifica se a tecla para a direita foi pressionada
        player.body.velocity.x = 350;
        player.animations.play('right');
	}
    else{
		//verifica se o player está parado
        player.animations.stop();
        player.frame = 4;
    }
		
	if (cursors.up.isDown && player.body.touching.down && hitPlatform)
	{
		//verifica se o player está em contato com o chão e ajusta o pulo
		player.body.velocity.y = -350;
	}
	
}










